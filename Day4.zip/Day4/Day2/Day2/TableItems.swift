//
//  TableItems.swift
//  Day2
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    static var Titles : [String] = ["Audio", "Video", "Web View", "Calendar", "Location", "Contacts"]
    static var Subtitles : [String] = ["Hear it clear", "Watch it better", "World is yours", "Time is not yours", "Be everywhere", "Stay Connected"]
    static var images : [String] = ["audio.png", "video.png", "web.png", "calendar.png", "location.png", "contacts.png"]}
