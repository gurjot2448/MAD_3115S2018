//
//  ViewController.swift
//  midterm
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbln1: UILabel!
    @IBOutlet weak var lbln2: UILabel!
    @IBOutlet weak var lbln3: UILabel!
    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var imgCheck: UIImageView!
    
    @IBAction func btnCheck(_ sender: UIButton)
    {
        var data : String = lbln1.text!
        data += "\n" + lbln3.text!
        data += "\n" + lbln2.text!
        data += "\n" + txt1.text!
        
        if txt1.text == String(txt)
        {
          
            //imgCheck =
            let alertController = UIAlertController(title: "Answer", message:
                "Correct Answer!", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Play again", style: UIAlertActionStyle.default,handler: nil))
              alertController.addAction(UIAlertAction(title: "Go to the Score Board!", style: UIAlertActionStyle.default,handler: nil))
            self.present(alertController, animated: true, completion: nil)
            self.imgCheck.image = UIImage(named:"correct")
            
        }
        else
        {
          
            let alertController = UIAlertController(title: "Answer", message:
                "Incorrect Answer!", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Play again", style: UIAlertActionStyle.default,handler: nil))
              alertController.addAction(UIAlertAction(title: "Go to the Score Board!", style: UIAlertActionStyle.default,handler: nil))
            self.present(alertController, animated: true, completion: nil)
               self.imgCheck.image = UIImage(named:"wrong")
            
        }

    }
   
  
        var n1 = Int(arc4random_uniform(10)+1)
        var n2 = Int(arc4random_uniform(10)+1)
        var n3 = Int(arc4random_uniform(4)+1)
        var txt : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view, typically from a nib.
        lbln1.text = String(n1)
        lbln2.text = String(n2)
        
        if n3 == 1
        {
            lbln3.text = "+"
            txt = n1 + n2
        }
        else if n3 == 2
        {
            lbln3.text = "-"
           txt = n1 - n2
        }
        else if n3 == 3
        {
            lbln3.text = "*"
            txt = n1 * n2
        }
        else if n3 == 4
        {
            lbln3.text = "/"
            txt = n1 / n2
        }
        
//        if let txt = UserDefaults.standard.value(forKey: "txt1")
//        {
//            txt1.text = txt as? String
//        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//    func displayViewController(){
//        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let VC = mainSB.instantiateViewController(withIdentifier: "ViewControllerScene")
//        navigationController?.pushViewController(VC, animated: true)
//    }//    @objc func btnSubmit()
//    {
//        var data : String = lbln1.text!
//        data += "\n" + lbln3.text!
//        data += "\n" + lbln2.text!
//        data += "\n" + txt1.text!
//
//
//    }
    
}

