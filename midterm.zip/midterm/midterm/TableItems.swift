//
//  TableItems.swift
//  midterm
//
//  Created by MacStudent on 2018-08-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    static var n1 : [String] = ["Audio", "Video", "Web View", "Calender", "Location", "Contacts"]
    static var n2 : [String] = ["Hear it clear", "Watch it better", "World is yours", "Time is not yours", "Be everywhere", "Stay Connected"]
    static var n3 : [String] = ["Audio", "Video", "Web", "Calender", "Location", "Contacts"]
    static var txt: [String] = []
    static var check: [String] = ["correct","wrong"]
}
