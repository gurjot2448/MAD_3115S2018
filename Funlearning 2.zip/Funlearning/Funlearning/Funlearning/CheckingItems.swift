//
//  CheckingItems.swift
//  Funlearning
//
//  Created by MacStudent on 2018-08-15.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class CheckingItems{
    
    static var imgCheck: [String] = ["cross","right"]
    static var equation: [String] = []
}
