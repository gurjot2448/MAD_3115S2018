//
//  ViewController.swift
//  Funlearning
//
//  Created by MacStudent on 2018-08-15.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    
    var result : Int? = 0
    
    
    
    @IBOutlet weak var lbln1: UILabel!
    
    
    @IBOutlet weak var lbln2: UILabel!
    @IBOutlet weak var lbln3: UILabel!
    
    @IBOutlet weak var txtanswer: UITextField!
    
    @IBOutlet weak var imgCheck: UIImageView!
    
    func play()
    {
        var randomNumber1 = Int(arc4random_uniform(10)+1)
        var randomNumber2 = Int(arc4random_uniform(10)+1)
        var randomNumber3 = Int(arc4random_uniform(4)+1)
       
        //var result : Int?
        
       lbln1.text = "\(randomNumber1)"
       lbln2.text = "\(randomNumber2)"
       lbln3.text = "\(randomNumber3)"
        
        if randomNumber3 == 1
        {
            lbln3.text = "+"
            result = randomNumber1 + randomNumber2
            //result = Int(txtanswer.text!)
            //print("\(result)")
            
        }else if randomNumber3 == 2
        {
            lbln3.text = "-"
            result = randomNumber1 - randomNumber2
            //result = Int(txtanswer.text!)
            
            //print("\(result)")
            
        }else if randomNumber3 == 3
        {
            lbln3.text = "*"
            result = randomNumber1 * randomNumber2
            //result = Int(txtanswer.text!)
            
            //print("\(result)")
        }else if randomNumber3 == 4
        {
            lbln3.text = "/"
            result = randomNumber1 / randomNumber2
            //result = Int(txtanswer.text!)
            
            //print("\(result)")
        }
        
        CheckingItems.equation.append("\(lbln1.text!)+ \(lbln3.text!) + \(lbln2.text!) = \(result)")
        
        
    }
 
    
    @IBAction func btnCheck(_ sender: UIButton) {
        print("r: \(result!) /// txt: \(txtanswer.text!))")
       
        if Int(txtanswer.text!) == result
        {
            print("r: \(result!) /// txt: \(Int(txtanswer.text!))")
            imgCheck.image = UIImage(named: "right")
            let infoAlert = UIAlertController(title: "Result", message: " Hoorayy... correct answer", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Play again!", style: .destructive, handler:{action in self.play()}))
            infoAlert.addAction(UIAlertAction(title: "Show progress!", style: .default, handler: {action in self.secondScene()}))
            self.present(infoAlert,animated: true)
        }
        else if Int(txtanswer.text!) != result
        {
            
            imgCheck.image = UIImage(named: "wrong")
            let infoAlert = UIAlertController(title: "Result", message: "wrong answer", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Retry", style: .destructive, handler:{action in self.play()}))
            self.present(infoAlert,animated: true)
            
        }
        
        
        
        
    }
    
   
    
    func secondScene()
    {
        let mainSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let homeeVC = mainSB.instantiateViewController(withIdentifier: "ProgressScene")
        navigationController?.pushViewController(homeeVC, animated: true)
    }
    
    
   
    override func viewDidLoad() {
       
        super.viewDidLoad()
        
        play()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

