//
//  ZodiacItems.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class ZodiacItems{
   
    static var zodiac : [String] = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarious","Pisces"]
    static var zodiacColours : [String] = ["Red","pink,Blue,Green","Yellow","Silver Blue","Smokey grey","Orange,Yellow","Green,Dark Brown"]
    static var zodiacBirthStone : [String] = ["BloodStone","Sapphire","Agate","Emerald","Onyx","Carnelian","Chrysolite","Beryl","Citrone","Ruby","Garnet","Amethyst"]
}
