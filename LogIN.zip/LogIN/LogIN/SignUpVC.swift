//
//  SignUpVC.swift
//  LogIN
//
//  Created by Harman Sidhu on 2018-08-07.
//  Copyright © 2018 Harman. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtContact: UITextField!
    @IBOutlet var txtAddress: UITextField!
    @IBOutlet var txtPostalCode: UITextField!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var txtCPassword: UITextField!
    @IBOutlet var segGender: UISegmentedControl!
    @IBOutlet var pickDOB: UIDatePicker!
    @IBOutlet var pickCity: UIPickerView!
    
    var cityList : [String] = ["Toronto", "Vancouver", "Edmenton", "Brampton", "Jasper", "Ottawa", "Calgary", "Banff"]
    var selectedCityIndex : Int = 0
    
    
    @objc func btnSubmit()
    {
        var data : String = txtName.text!
        data += "\n" + txtContact.text!
        data += "\n" + txtAddress.text!
        data += "\n" + txtPostalCode.text!
        data += "\n" + txtEmail.text!
        data += "\n" + txtPassword.text!
        data += "\n" + txtCPassword.text!
        data += "\n \(pickDOB.date)"
        
        selectedCityIndex = pickCity.selectedRow(inComponent: 0)
        data += "\n \(cityList[selectedCityIndex])"
        
        switch segGender.selectedSegmentIndex
        {
        case 0 :
                 data += "\n Male"
        case 1 :
                  data += "\n Female"
        case 2:
                  data += "\n Other"
        default:
                  data += "\n No Disclosure"
        }
        
        let infoAlert = UIAlertController(title: "Confirm Details", message: data, preferredStyle: .alert)
        if txtCPassword.text != txtCPassword.text
        {
            infoAlert.message = "Password and confirm password must be same"
        }
        else
        {
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayHomeVC()}))
        }
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        navigationController?.setNavigationBarHidden(false, animated: true)
        self.title = "Sign Up"
        
        let btnDone = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(btnSubmit))
        self.navigationItem.rightBarButtonItem = btnDone
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        pickCity.dataSource = self
        pickCity.delegate = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return cityList.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return cityList[row]
    }
    
    func displayHomeVC ()
    {
        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
        navigationController?.pushViewController(homeVC, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
