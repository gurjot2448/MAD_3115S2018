//
//  ZodiacItems.swift
//  Day2
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class ZodiacItems{
    static var zodiac : [String] = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
    static var zodiacColors : [String] = ["Red", "Pink, Blue, Green", "Yellow", "Silver Blue , Smokey Grey", "Orange, Yellow", "Green, Dark Brown", "Pink", "Deep Red, Maroon", "Rich Purple, Dark Blues", "Green, Grey, Black, Brown", "Electric Blue, Turquiose", "Soft Sea Green"]
    static var zodiacBirthStone : [String] = ["BloodStone", "Sapphire", "Agate", "Emerald", "Onyx", "Carnelian", "Chrysolite", "Beryl", "Citrone", "Ruby", "Garnet", "Amethyst"]
    }
